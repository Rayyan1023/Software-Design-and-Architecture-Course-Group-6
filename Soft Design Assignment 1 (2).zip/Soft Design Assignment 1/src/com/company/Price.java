package com.company;

// Declares prices for the shoe types
public enum Price {
    // Dress Shoes
    $100,
    // High Heels
    $80,
    // Running Shoes
    $40,
    // Slippers
    $20
}
