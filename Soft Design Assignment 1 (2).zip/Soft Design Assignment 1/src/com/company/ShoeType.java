package com.company;

// Declares all shoe types
public enum ShoeType {
    DRESS,
    HIGHHEELS,
    RUNNING,
    SLIPPERS
}
